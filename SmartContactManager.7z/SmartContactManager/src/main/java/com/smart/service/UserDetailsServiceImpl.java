package com.smart.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.smart.config.CustomUserDeatails;
import com.smart.dao.UserRepository;
import com.smart.entities.User;

public class UserDetailsServiceImpl implements UserDetailsService{

	@Autowired
	private UserRepository userrepository;
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		
		User user=userrepository.getUserByUserName(username);
		if(user==null) {
			throw new UsernameNotFoundException("User not found");
		}
		
		CustomUserDeatails customUserDetails=new CustomUserDeatails(user);
		return customUserDetails;
	}

}
