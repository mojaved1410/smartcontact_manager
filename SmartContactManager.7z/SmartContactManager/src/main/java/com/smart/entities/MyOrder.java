/**
 * File Name : MyOrder.java
 * This project is the propery of javed CopyRight (@) 2021
 * @Author : javed
 * @Date : 14-Aug-2021
 */
package com.smart.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

/**
 * @author javed
 *
 */
@Entity
@Table(name="orders")
public class MyOrder {

	@Id @GeneratedValue(generator="system-uuid")
	@GenericGenerator(name="system-uuid", strategy = "uuid")

	private String MyOrderid;
	
	private String orderId;
	private String amount;
	private String receipt;
	private String status;
	private String paymentId;
	
	public String getPaymentId() {
		return paymentId;
	}
	public void setPaymentId(String paymentId) {
		this.paymentId = paymentId;
	}
	@ManyToOne
	private User user;
	
	public MyOrder() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getMyOrderid() {
		return MyOrderid;
	}
	public void setMyOrderid(String myOrderid) {
		MyOrderid = myOrderid;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public String getReceipt() {
		return receipt;
	}
	public void setReceipt(String receipt) {
		this.receipt = receipt;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	

	
}
