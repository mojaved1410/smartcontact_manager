/**
 * File Name : LogginAdvice.java
 * This project is the propery of javed CopyRight (@) 2021
 * @Author : pc
 * @Date : 13-Aug-2021
 */
package com.smart.advice;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

/**
 * @author javed
 *
 */
@Aspect
@Component
@Slf4j
public class LogginAdvice {

	private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(LogginAdvice.class);
	@After("execution(* com.smart..*(..))")

    public void afterAdvice(final JoinPoint joinPoint) {

           log.info("Method invoked : {} {}", joinPoint.getTarget().getClass(), joinPoint.getSignature().getName());

    }
}
