package com.smart;
import org.apache.log4j.Logger;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.ulisesbocchio.jasyptspringboot.annotation.EnableEncryptableProperties;

@SpringBootApplication
@EnableEncryptableProperties
public class SmartContactManagerApplication {

	public static Logger logger = Logger.getLogger(SmartContactManagerApplication.class);
	public static void main(String[] args) {
		SpringApplication.run(SmartContactManagerApplication.class, args);
		
		
		logger.trace("A TRACE Message");
        logger.debug("A DEBUG Message");
        logger.info("An INFO Message");
        logger.warn("A WARN Message");
        logger.error("An ERROR Message");
	}

}
