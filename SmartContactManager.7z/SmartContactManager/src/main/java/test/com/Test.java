/**
 *File Name Test.java
 * This project is the propery of javed CopyRight (@) 2021
 * @Author pc
 * @date 04-Aug-2021
 */
package test.com;

/**
 * @author pc
 *
 */
public class Test {

	int x;
	String name;
	
	
	



	public Test(int x, String name) {
		super();
		this.x = x;
		this.name = name;
	}






	/**
	 * 
	 * @Author pc
	 * Date : 04-Aug-2021
	 * Return Type : void
	 */
	public void m1() {
		
	}
}
