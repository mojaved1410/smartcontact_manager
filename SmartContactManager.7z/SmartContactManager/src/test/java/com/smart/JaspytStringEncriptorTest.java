/**
 * File Name : JaspytStringEncriptorTest.java
 * This project is the propery of javed CopyRight (@) 2021
 * @Author : pc
 * @Date : 13-Aug-2021
 */
package com.smart;

import org.jasypt.encryption.pbe.PooledPBEStringEncryptor;
import org.jasypt.encryption.pbe.config.SimpleStringPBEConfig;
import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;
import lombok.extern.slf4j.Slf4j;
/**
 * @author javed
 *
 */
@SpringBootTest
@Slf4j
public class JaspytStringEncriptorTest {

	private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(JaspytStringEncriptorTest.class);
	 @Test
     public void testEncryptionKey() {
		 
            PooledPBEStringEncryptor encryptor = new PooledPBEStringEncryptor();
            SimpleStringPBEConfig config = new SimpleStringPBEConfig();
            config.setPassword("password"); // encryptor's private key
            config.setAlgorithm("PBEWithMD5AndDES");
            config.setKeyObtentionIterations("1000");
            config.setPoolSize("1");
            config.setProviderName("SunJCE");
            config.setSaltGeneratorClassName("org.jasypt.salt.RandomSaltGenerator");
            config.setStringOutputType("base64");
            encryptor.setConfig(config);
            String plaintext = "root";
            
            log.info("Encrypted key : " + encryptor.encrypt(plaintext));

	 }
}
